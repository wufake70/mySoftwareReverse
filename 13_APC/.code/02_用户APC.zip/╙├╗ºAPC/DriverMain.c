#include <ntifs.h>
#include "stuct.h"




VOID kernelRoutineFunc(
	IN struct _KAPC *Apc,
	IN OUT PKNORMAL_ROUTINE *NormalRoutine,
	IN OUT PVOID *NormalContext,
	IN OUT PVOID *SystemArgument1,
	IN OUT PVOID *SystemArgument2
)
{

	DbgPrintEx(77, 0, "[db]:---------kernelRoutineFunc pid = %d--------------\r\n", PsGetCurrentProcessId());
	DbgPrintEx(77, 0, "[db]:kernelRoutineFunc\r\n");
	ULONG64 addr = 0x401030;
	PsWrapApcWow64Thread(NULL, &addr);
	DbgBreakPoint();
	*NormalRoutine = addr;
	
	ExFreePool(Apc);
}


VOID DriverUnload(PDRIVER_OBJECT pDriver)
{

}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	PKAPC pApc = ExAllocatePool(NonPagedPool, sizeof(KAPC));
	memset(pApc, 0, sizeof(KAPC));

	PKEVENT pEvent = ExAllocatePool(NonPagedPool, sizeof(KEVENT));
	memset(pEvent, 0, sizeof(KEVENT));

	KeInitializeEvent(pEvent, SynchronizationEvent, FALSE);

	PETHREAD eThread = NULL;
	PsLookupThreadByThreadId(3676, &eThread);

	
	DbgPrintEx(77, 0, "[db]:---------main pid = %d--------------\r\n", PsGetCurrentProcessId());
	KeInitializeApc(pApc, eThread, OriginalApcEnvironment,
		kernelRoutineFunc, NULL, 0x401030, UserMode, (PVOID)1);
	
	*((PUCHAR)eThread + 0x4c) |= 0x20;
	BOOLEAN is = KeInsertQueueApc(pApc, pEvent, NULL, 0);
	KeAlertThread(eThread, UserMode);


	DbgPrintEx(77, 0, "[db]:-----------------------\r\n");
	if (!is)
	{
		ExFreePool(pApc);
		ExFreePool(pEvent);
	}
	else
	{
		
		DbgPrintEx(77, 0, "[db]:-----------111111111------------\r\n");
		ExFreePool(pEvent);
	}
	pDriver->DriverUnload = DriverUnload;
	return STATUS_SUCCESS;
}