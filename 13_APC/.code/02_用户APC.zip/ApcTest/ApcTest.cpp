// ApcTest.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <Windows.h>

VOID Test(PVOID param1, PVOID param2, PVOID param3)
{
	printf("Apc��ִ��\r\n");
}

int main()
{
	printf("%d,Test = %x\r\n", GetCurrentThreadId(),Test);
	system("pause");
	while (1)
	{
		printf("--------------------\r\n");
		Sleep(100000);
	}

    return 0;
}

