#include "stdafx.h"
#include "petool.h"
#include "petool2.h"

//int dos_size=sizeof _IMAGE_DOS_HEADER;

int main(int argc, char* argv[])
{
	int operate_code=4;
	char pepath[100]="notepad.exe";
	char* buffer=NULL;
	dos_head* p_dos=NULL;
	nt_head* p_nt=NULL;
	stdpe_head* p_stdpe=NULL;
	optpe_head* p_optpe=NULL;
	optpe64_head* p_optpe64=NULL;

	printf("Put a pe path:\n\t");
	scanf("%s",pepath);

	buffer=readpe(pepath);
	
	

	while(1){
		printf("[0]DOS_HEADER [1]NT_HEADER [2]STDPE_HEADER [3]OPTPE_HEADER [4]OtherPE [5]EXIT:\n\t");
		scanf("%d",&operate_code);
		switch(operate_code)
		{
			case 0:
				p_dos=GetPE_DosPtr(buffer);
				GetPEinfo_Dos(p_dos);
				break;
			case 1:
				p_nt=GetPE_NtPtr(buffer);
				GetPEinfo_NT(p_nt);
				break;
			case 2:
				p_stdpe=GetPE_StdPtr(buffer);
				GetPEinfo_stdPE(p_stdpe);
				break;
			case 3:

				// ��ѡpeͷ��x32��x86
				p_stdpe=GetPE_StdPtr(buffer);
				if(p_stdpe->Machine==0x14c)
				{
					p_optpe=GetPE_OptPtr(buffer);
					GetPEinfo_optPE(p_optpe);				
				}else{
					p_optpe64=GetPE_Opt64Ptr(buffer);
					GetPEinfo_optPE64(p_optpe64);
				}
				break;
			case 4:
				free(buffer); // �����ڴ�й¶
				printf("Put a pe path:\n\t");
				scanf("%s",pepath);
				buffer=readpe(pepath);
				break;

			case 5:
				exit(0);
		}
		printf("\n\n");
	}

	free(buffer);
	getchar();
	getchar();
	
	return 0;
}
