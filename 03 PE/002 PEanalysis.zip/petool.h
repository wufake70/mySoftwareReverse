#if !defined(AFX_PETOOL_H__BC9AE6DA_8D52_4356_9802_921968C7E3DA__INCLUDED_)
#define AFX_PETOOL_H__BC9AE6DA_8D52_4356_9802_921968C7E3DA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


char* readpe(char* pepath)
{
	char* buffer=NULL;
	int i=0;
	FILE* fp=NULL;

	if(fp=fopen(pepath,"rb"))
	{
		i++;
		fseek(fp,0,SEEK_END);
		int size=ftell(fp);
		rewind(fp);
		buffer=(char*)malloc(sizeof(char)*size);
		if(buffer)
		{
			i++;
			size_t result=fread(buffer,1,size,fp);
			if(result==(unsigned int)size){
				i++;
			}
		}
	}

	switch(i)
	{
		case 0:
			printf("%s file do't exist.\n",pepath);
			break;
		case 1:
			printf("memory not enough.\n");
			fclose(fp);
			break;
		case 2:
			printf("read pe fail.\n");
			free(buffer);
			fclose(fp);
			break;

		default:
			printf("read pe successful.\n");
			//free(buffer);
			fclose(fp);
			return buffer;
	}

	return NULL;
}


dos_head* GetPE_DosPtr(char* buffer)
{
	struct dos_head* p=(struct dos_head*)buffer;
	if(p)
	{
		return p;
	}else{
		return NULL;
	}
}




nt_head* GetPE_NtPtr(char* buffer)
{
	struct nt_head* p=(struct nt_head*)&buffer[((struct dos_head*)buffer)->e_lfanew];
	if(p)
	{
		return p;
	}else{
		return NULL;
	}
}




void GetPEinfo_stdPE(stdpe_head* p_stdpe)
{
	if(p_stdpe)
	{
		char* strformat="_IMAGE_FILE_HEADER{"
						"\n\tMachine: 0x%08x"
						"\n\tNumberOfSections: 0x%08x"
						"\n\tTimeDateStamp: 0x%08x"
						"\n\tPointerToSymbolTable: 0x%08x"
						"\n\tNumberOfSymbols: 0x%08x"
						"\n\tSizeOfOptionalHeader: 0x%08x"
						"\n\tCharacteristics: 0x%08x\n}";
		printf(strformat,
				p_stdpe->Machine,
				p_stdpe->NumberOfSections,
				p_stdpe->TimeDateStamp,
				p_stdpe->PointerToSymbolTable,
				p_stdpe->NumberOfSymbols,
				p_stdpe->SizeOfOptionalHeader,
				p_stdpe->Characteristics);

	}else{
		printf("get a NULL.\n");
	}
}

stdpe_head* GetPE_StdPtr(char* buffer)
{
	struct stdpe_head* p=(struct stdpe_head*)&((struct nt_head*)&buffer[((struct dos_head*)buffer)->e_lfanew])->FileHeader;
	if(p)
	{
		return p;
	}else{
		return NULL;
	}
}

optpe_head* GetPE_OptPtr(char* buffer)
{
	struct optpe_head* p=(struct optpe_head*)&((struct nt_head*)&buffer[((struct dos_head*)buffer)->e_lfanew])->OptionalHeader;

	if(p)
	{
		return p;
	}else{
		return NULL;
	}
}



optpe64_head* GetPE_Opt64Ptr(char* buffer)
{
	struct optpe64_head* p=(struct optpe64_head*)&((struct nt64_head*)&buffer[((struct dos_head*)buffer)->e_lfanew])->OptionalHeader;
	if(p)
	{
		return p;
	}else{
		return NULL;
	}
}



#endif // !defined(AFX_PETOOL_H__BC9AE6DA_8D52_4356_9802_921968C7E3DA__INCLUDED_)
